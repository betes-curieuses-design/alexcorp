<?php 
class Cms5a73d47dc0880497180066_927a5c12e1a2bd5469f24e27aaa165aeClass extends \Cms\Classes\PageCode
{

}
