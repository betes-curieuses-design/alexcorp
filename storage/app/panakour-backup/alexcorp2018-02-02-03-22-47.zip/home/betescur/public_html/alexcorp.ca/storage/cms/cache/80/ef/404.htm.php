<?php 
class Cms5a73d1a9a969b428175755_da0f7bbe4ae1248807cae1de16ade50aClass extends \Cms\Classes\PageCode
{

}
