<?php

namespace Adrenth\Redirect\Updates;

use October\Rain\Database\Updates\Migration;

/**
 * Class Publish
 *
 * @package Adrenth\Redirect\Updates
 */
class Publish extends Migration
{
    public function up()
    {
        // See commit: 249c783fe73c602549f4e9d69789844341b9b5b2 (1.1.0)
        // This migration was removed, but fails when uninstalling plugin
    }

    public function down()
    {
        // See commit: 249c783fe73c602549f4e9d69789844341b9b5b2 (1.1.0)
        // This migration was removed, but fails when uninstalling plugin
    }
}
