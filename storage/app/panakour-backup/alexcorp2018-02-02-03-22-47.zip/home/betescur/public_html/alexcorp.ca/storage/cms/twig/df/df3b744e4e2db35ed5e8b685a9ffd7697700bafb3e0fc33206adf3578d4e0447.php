<?php

/* /home/betescur/public_html/alexcorp.ca/themes/jtherczeg-corlate/partials/services.htm */
class __TwigTemplate_12200c9f13df6d48767435aaa21993a1b83719b3571d1196efed0c15c1ca5b13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">

            <div class=\"row\">

                <div class=\"col-sm-6 col-md-4\">
                    <div class=\" wow fadeInDown\">
                        <div id=\"content-box\">
                            <h2>Je carbure à la caféine,
                                voici mes compétences</h2>
                            <div class=\"top-buffer\">
                            <table class=\"table\">
                                <tr>
                                    <td>Photoshop CS6</td>
                                    <td>
                                        <img src=\"";
        // line 15
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>Illustrator CS6</td>
                                    <td><img src=\"";
        // line 19
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>InDesign CS6</td>
                                    <td><img src=\"";
        // line 23
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>Affinity Designer</td>
                                    <td><img src=\"";
        // line 27
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>Affinity Photo</td>
                                    <td><img src=\"";
        // line 31
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>Acrobat Pro 10</td>
                                    <td><img src=\"";
        // line 35
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\">  <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\">  <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\">  <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\">  <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>QuarkXPress 7</td>
                                    <td><img src=\"";
        // line 39
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>HTML5/CSS3</td>
                                    <td><img src=\"";
        // line 43
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>OctoberCMS</td>
                                    <td><img src=\"";
        // line 47
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>Esko Artwork</td>
                                    <td><img src=\"";
        // line 51
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                                <tr>
                                    <td>Suite Office 2011</td>
                                    <td><img src=\"";
        // line 55
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_full.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"> <img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/apple_minus.png");
        echo "\"></td>
                                </tr>
                            </table>
                                </div>
                        </div>
                    </div>
                </div>

                </div>
        </div><!--/.container-->";
    }

    public function getTemplateName()
    {
        return "/home/betescur/public_html/alexcorp.ca/themes/jtherczeg-corlate/partials/services.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 55,  170 => 51,  155 => 47,  140 => 43,  125 => 39,  110 => 35,  95 => 31,  80 => 27,  65 => 23,  50 => 19,  35 => 15,  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">

            <div class=\"row\">

                <div class=\"col-sm-6 col-md-4\">
                    <div class=\" wow fadeInDown\">
                        <div id=\"content-box\">
                            <h2>Je carbure à la caféine,
                                voici mes compétences</h2>
                            <div class=\"top-buffer\">
                            <table class=\"table\">
                                <tr>
                                    <td>Photoshop CS6</td>
                                    <td>
                                        <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>Illustrator CS6</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>InDesign CS6</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>Affinity Designer</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>Affinity Photo</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>Acrobat Pro 10</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\">  <img src=\"{{ 'assets/images/apple_full.png'|theme }}\">  <img src=\"{{ 'assets/images/apple_full.png'|theme }}\">  <img src=\"{{ 'assets/images/apple_full.png'|theme }}\">  <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>QuarkXPress 7</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>HTML5/CSS3</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>OctoberCMS</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>Esko Artwork</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                                <tr>
                                    <td>Suite Office 2011</td>
                                    <td><img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_full.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"> <img src=\"{{ 'assets/images/apple_minus.png'|theme }}\"></td>
                                </tr>
                            </table>
                                </div>
                        </div>
                    </div>
                </div>

                </div>
        </div><!--/.container-->", "/home/betescur/public_html/alexcorp.ca/themes/jtherczeg-corlate/partials/services.htm", "");
    }
}
