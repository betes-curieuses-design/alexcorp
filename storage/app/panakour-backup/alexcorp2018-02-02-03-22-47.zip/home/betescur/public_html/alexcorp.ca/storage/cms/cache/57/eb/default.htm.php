<?php 
class Cms5a73d1a9a88d5611198926_3c43fe818ede8e13bbdb95d968199a83Class extends \Cms\Classes\LayoutCode
{

}
