<?php 
class Cms5a73d47dccba0873974976_983ac538ac961a1d1b4590d86a202c8aClass extends \Cms\Classes\PartialCode
{

}
