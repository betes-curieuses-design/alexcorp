<?php 
class Cms5a73d1a9f17e5625234160_dc983554b619118f0989d4313b0bbc25Class extends \Cms\Classes\PartialCode
{

}
