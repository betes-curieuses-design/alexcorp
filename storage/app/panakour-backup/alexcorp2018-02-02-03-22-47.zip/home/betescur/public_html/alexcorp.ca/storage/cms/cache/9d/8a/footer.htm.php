<?php 
class Cms5a73d1aa00a9e875262743_c897e07fe4263c88f92161bc8baa8c1aClass extends \Cms\Classes\PartialCode
{

}
