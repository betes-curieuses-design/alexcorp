<?php 
class Cms5a73d47dcfaec279798941_fabfc3997c4e4f1e990bf93fa7ec3132Class extends \Cms\Classes\PartialCode
{

}
