<?php

namespace Adrenth\Redirect\Updates;

use October\Rain\Database\Updates\Seeder;

/**
 * Class SeedRedirectsTable
 *
 * @package Adrenth\Redirect\Updates
 */
class SeedRedirectsTable extends Seeder
{
    /**
     * {@inheritdoc}
     */
    public function run()
    {
    }
}
