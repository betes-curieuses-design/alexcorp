# work

## AJAX based Portfolio plugin for OctoberCMS

With this plugin you can create a portfolio into OctoberCMS.

The plugin has a Component called Worklist that you can insert from the backend in any page you want to. 

You have a list of works and forms to create and edit each item of the portfolio. I have used the Sortable Trait to order by drag & drop the items of the  portfolio list.

This plugin needs JQuery. You can import it in your theme, for example.

In order to work properly, this plugin needs October Ajax Framework https://octobercms.com/docs/cms/ajax

You can use it in your layout using the twigg tag  {% framework extras %}
