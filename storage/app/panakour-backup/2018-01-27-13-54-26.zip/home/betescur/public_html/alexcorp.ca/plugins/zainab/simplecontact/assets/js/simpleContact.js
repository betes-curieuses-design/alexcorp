function printMessage() {
    $('.print-body').printThis();
}
