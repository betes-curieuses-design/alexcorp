<?php 
class Cms5ad10c826fcc5000958368_c3e95eb91033a3e8b770e43a0e4ba95cClass extends \Cms\Classes\LayoutCode
{

}
