$(document).ready(function () {

    var $indicator = $('.loading-indicator-container');

    $('.create-backup').on('click', function () {
        $indicator.css('display', 'inline-block');
    });

});

