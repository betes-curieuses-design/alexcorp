<?php 
class Cms5ad10c834365b641239458_1630bfe0068e138683901aae906a54c3Class extends Cms\Classes\PartialCode
{

}
