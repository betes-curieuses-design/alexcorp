$('#carousel').carousel({
    interval: 4000
});