<?php 
class Cms5ad10c82728c4722927413_f8ed18e48a37245aabc2fb2f43312153Class extends \Cms\Classes\PageCode
{

}
