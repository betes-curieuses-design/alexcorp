<?php 
class Cms5ad10c833ba86214054990_750887645d67015b4a238e83a665fcddClass extends Cms\Classes\PartialCode
{

}
