<?php 
class Cms5ad133f8d150c291074283_59d820b7f2f2d754f560f9565ab16306Class extends \Cms\Classes\PageCode
{

}
