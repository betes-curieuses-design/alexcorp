<?php 
class Cms5ad10c82d9a32680849687_3631f4e6cbb539413b61d124ce3c059dClass extends Cms\Classes\PartialCode
{

}
