<?php 
class Cms5ad10c82d6bbd692546050_6efa62b3f5b94271baf3ab0200141c74Class extends Cms\Classes\PartialCode
{

}
