<?php

/* /home/betescur/public_html/alexcorp.ca/themes/jtherczeg-corlate/partials/features.htm */
class __TwigTemplate_cde9445e94e562afacfcd8cc10b2a213c3204c0ea1b2ec842721baa2de6f396b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
    <div class=\"center wow fadeInDown\">
        <div class=\"row\">
            <div id=\"content-box\" class=\"col-sm-6 pull-right wow fadeInRight\">
                <h2>À propos de moi</h2>
                <p class=\"lead\">Diplômé en design graphique au collège Marie-Victorin en 2012, j'exerce ce métier avec
                    passion et dynamisme.</p>
                <p class=\"lead\">On dit de moi que je suis quelqu'un de fiable, de ponctuel et de constament positif.</p>
                <p class=\"lead\"> J'adore dépasser mes limites et avoir de nouveaux défis.</p>
            </div>
        </div><!--/.services-->
    </div><!--/.row-->
</div><!--/.container-->";
    }

    public function getTemplateName()
    {
        return "/home/betescur/public_html/alexcorp.ca/themes/jtherczeg-corlate/partials/features.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
    <div class=\"center wow fadeInDown\">
        <div class=\"row\">
            <div id=\"content-box\" class=\"col-sm-6 pull-right wow fadeInRight\">
                <h2>À propos de moi</h2>
                <p class=\"lead\">Diplômé en design graphique au collège Marie-Victorin en 2012, j'exerce ce métier avec
                    passion et dynamisme.</p>
                <p class=\"lead\">On dit de moi que je suis quelqu'un de fiable, de ponctuel et de constament positif.</p>
                <p class=\"lead\"> J'adore dépasser mes limites et avoir de nouveaux défis.</p>
            </div>
        </div><!--/.services-->
    </div><!--/.row-->
</div><!--/.container-->", "/home/betescur/public_html/alexcorp.ca/themes/jtherczeg-corlate/partials/features.htm", "");
    }
}
